﻿namespace EMPLOYEE_FORM.Models
{
    public class DesignationModel
    {
        public int DesignationID { get; set; }
        public int DesignationName { get; set; }
    }
}
