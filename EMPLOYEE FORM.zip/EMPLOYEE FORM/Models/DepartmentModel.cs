﻿namespace EMPLOYEE_FORM.Models
{
    public class DepartmentModel
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public int DepartmentCode { get; set; }
    }
}
