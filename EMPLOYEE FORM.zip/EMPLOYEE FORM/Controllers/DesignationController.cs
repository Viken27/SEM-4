﻿using Microsoft.AspNetCore.Mvc;

namespace EMPLOYEE_FORM.Controllers
{
    public class DesignationController : Controller
    {
        public IActionResult DesignationForm()
        {
            return View();
        }
        public IActionResult DesignationList()
        {
            return View();
        }
    }
}
