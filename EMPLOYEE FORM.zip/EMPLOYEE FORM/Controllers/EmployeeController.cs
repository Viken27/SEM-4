﻿using Microsoft.AspNetCore.Mvc;

namespace EMPLOYEE_FORM.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult EmployeeForm()
        {
            return View();
        }
        public IActionResult EmployeeList()
        {
            return View();
        }
    }
}
