﻿using Microsoft.AspNetCore.Mvc;

namespace EMPLOYEE_FORM.Controllers
{
    public class DepartmentController : Controller
    {
        public IActionResult DepartmentForm()
        {
            return View();
        }
        public IActionResult DepartmentList()
        {
            return View();
        }
    }
}
