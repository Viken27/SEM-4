﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ProgramExam
{
    internal class Book
    {
        int book_id;
        string title;
        string author;
        public void book(int book_id, string title, string author)
        {
            this.book_id = book_id;
            this.title = title;
            this.author = author;
        }
        public void Get_book_Details()
        {
            Console.WriteLine("enter a Bookid:-");
            int book_id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter a Tittle:-");
            string tittle = Console.ReadLine();
            Console.WriteLine("enter a Author:-");
            string author = Console.ReadLine();
        }
        public void display_bookdetails()
        {
            Console.WriteLine($"the book id is{book_id},");
            Console.WriteLine($"the book tittle is{title},");
            Console.WriteLine($"the book author is{author},");
        }
    }
}
