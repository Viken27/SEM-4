﻿using System.ComponentModel.DataAnnotations;
namespace ProgramExam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a program number ");
            int x = Convert.ToInt32(Console.ReadLine());
            switch (x)
            {
                case 1:
                    {
                        Console.Write("Enter size of array : ");
                        int n = Convert.ToInt32(Console.ReadLine());
                        int[] a = new int[n];
                        for (int i = 0; i < n; i++)
                        {
                            Console.Write("Enter the " + (i + 1) + "th value of array : ");
                            a[i] = Convert.ToInt32(Console.ReadLine());
                        }
                        int Large = a[0];
                        int Small = a[0];
                        for (int i = 1; i < a.Length; i++)
                        {
                            if (a[i] < Small)
                            {
                                Small = a[i];
                            }
                            else if (a[i] > Large)
                            {
                                Large = a[i];
                            }
                        }
                        Console.WriteLine("Largest Number = " + Large + " & Smallest number = " + Small);
                        break;
                    }
                case 2:
                    {
                        Console.Write("Enter the Second : ");
                        double t = Convert.ToDouble(Console.ReadLine());
                        t = t / 3600;
                        int H = Convert.ToInt32(t);
                        Console.Write(H + " Houre : ");
                        t = t - H;
                        t = t * 60;
                        int M = Convert.ToInt32(t);
                        Console.Write(M + " Mintes : ");
                        t = t - M;
                        t = t * 60;
                        int S = Convert.ToInt32(t);
                        Console.Write(S + " Second : ");
                        break;
                    }
                case 3:
                    {
                        Book book = new Book();
                        book.Get_book_Details();
                        book.display_bookdetails();
                        break;
                    }
            }
        }
    }
}
