﻿using Microsoft.AspNetCore.Mvc;

namespace Lab_6.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult ListOfStudent()
        {
            return View("StudentList");
        }
    }
}
